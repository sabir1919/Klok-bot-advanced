
const fs = require("fs");
const axios = require("axios");
const HttpsProxyAgent = require("https-proxy-agent");
const { ethers } = require("ethers");

const config = JSON.parse(fs.readFileSync("config.json", "utf8"));

let sessionIndex = 0;
let keyIndex = 0;
let proxyIndex = 0;
let chatCount = 0;

const prompts = [
  "What's your favorite book?",
  "Tell me a joke!",
  "What's the weather like today?",
  "How do I learn JavaScript?",
  "What is the capital of Italy?",
  "Give me a productivity tip.",
  "How does a blockchain work?",
  "Tell me a fun fact."
];

function getNext(array, index) {
  return array[index % array.length];
}

function log(message) {
  const timestamp = new Date().toISOString();
  fs.appendFileSync("log.txt", `[${timestamp}] ${message}\n`);
  console.log(message);
}

async function farm() {
  while (true) {
    try {
      const sessionToken = getNext(config.session_tokens, sessionIndex++);
      const privateKey = getNext(config.private_keys, keyIndex++);
      const proxyUrl = getNext(config.proxies, proxyIndex++);

      const headers = {
        Authorization: sessionToken,
        "Content-Type": "application/json"
      };

      const agent = new HttpsProxyAgent(proxyUrl);
      const wallet = new ethers.Wallet(privateKey);
      const prompt = prompts[Math.floor(Math.random() * prompts.length)];

      const chatRes = await axios.post(
        "https://klokapp.ai/api/chat",
        { name: "Auto Chat", model: "gpt-3.5-turbo" },
        { headers, httpsAgent: agent }
      );

      const chatId = chatRes.data.chat_id;
      log(`[+] Created chat: ${chatId} | Wallet: ${wallet.address} | Proxy: ${proxyUrl}`);

      await axios.post(
        `https://klokapp.ai/api/chat/${chatId}/message`,
        { content: prompt },
        { headers, httpsAgent: agent }
      );

      log(`[+] Sent prompt: "${prompt}" | Chat: ${chatId}`);

      chatCount++;
      log(`[+] Total chats: ${chatCount}\n`);

      const waitTime = 10000 + Math.floor(Math.random() * 10000);
      await new Promise((r) => setTimeout(r, waitTime));
    } catch (err) {
      log(`[-] Error: ${err.response?.data?.message || err.message}`);
      await new Promise((r) => setTimeout(r, 15000));
    }
  }
}

farm();
